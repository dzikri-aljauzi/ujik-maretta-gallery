import { type NextRequest, NextResponse } from "next/server"
import { put } from "@vercel/blob"
import { v4 as uuidv4 } from "uuid"
import { addPhoto } from "@/lib/photos"
import { revalidatePath } from "next/cache"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File
    const caption = formData.get("caption") as string
    const description = formData.get("description") as string
    const partner = formData.get("partner") as string

    if (!file || !caption || !partner) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Generate a safe filename
    const filename = file.name.replace(/[^a-zA-Z0-9.-]/g, "_")
    const uniqueFilename = `photos/${uuidv4()}-${filename}`

    // Upload to Vercel Blob
    const blob = await put(uniqueFilename, file, {
      access: "public",
      contentType: file.type,
    })

    // Create photo object
    const photo = {
      id: uuidv4(),
      url: blob.url,
      caption,
      description: description || "",
      date: new Date().toISOString(),
      partner,
    }

    // Save to our data store
    await addPhoto(photo)

    // Revalidate paths
    revalidatePath("/")
    revalidatePath(`/profiles/${partner}`)

    return NextResponse.json({ success: true, photo })
  } catch (error) {
    console.error("Error uploading photo:", error)
    return NextResponse.json({ error: "Failed to upload photo" }, { status: 500 })
  }
}
