import { type NextRequest, NextResponse } from "next/server"
import { put } from "@vercel/blob"
import { v4 as uuidv4 } from "uuid"
import { updatePartnerProfile } from "@/lib/profiles"
import { revalidatePath } from "next/cache"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File
    const partnerId = formData.get("partnerId") as string

    if (!file || !partnerId) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Generate a safe filename
    const filename = file.name.replace(/[^a-zA-Z0-9.-]/g, "_")
    const uniqueFilename = `avatars/${partnerId}-${uuidv4()}-${filename}`

    // Upload to Vercel Blob
    const blob = await put(uniqueFilename, file, {
      access: "public",
      contentType: file.type,
    })

    // Update profile
    await updatePartnerProfile(partnerId, {
      avatar: blob.url,
    })

    // Revalidate path
    revalidatePath(`/profiles/${partnerId}`)

    return NextResponse.json({ success: true, url: blob.url })
  } catch (error) {
    console.error("Error uploading avatar:", error)
    return NextResponse.json({ error: "Failed to upload avatar" }, { status: 500 })
  }
}
