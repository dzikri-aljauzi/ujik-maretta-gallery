import fs from "fs/promises"
import path from "path"
import type { Photo } from "./types"

const DATA_PATH = path.join(process.cwd(), "data")
const PHOTOS_FILE = path.join(DATA_PATH, "photos.json")

// Ensure data directory exists
async function ensureDataDir() {
  try {
    await fs.access(DATA_PATH)
  } catch {
    await fs.mkdir(DATA_PATH, { recursive: true })
  }
}

// Get all photos
export async function getPhotos(): Promise<Photo[]> {
  await ensureDataDir()

  try {
    const data = await fs.readFile(PHOTOS_FILE, "utf-8")
    return JSON.parse(data) as Photo[]
  } catch (error) {
    // If file doesn't exist, create an empty file
    await fs.writeFile(PHOTOS_FILE, JSON.stringify([], null, 2))
    return []
  }
}

// Get photos by partner
export async function getPhotosByPartner(partnerId: string): Promise<Photo[]> {
  try {
    const photos = await getPhotos()
    return photos.filter((photo) => photo.partner === partnerId)
  } catch (error) {
    console.error("Error getting photos by partner:", error)
    return []
  }
}

// Save photos
export async function savePhotos(photos: Photo[]): Promise<void> {
  await ensureDataDir()
  try {
    await fs.writeFile(PHOTOS_FILE, JSON.stringify(photos, null, 2))
  } catch (error) {
    console.error("Error saving photos:", error)
  }
}

// Add a new photo
export async function addPhoto(photo: Photo): Promise<void> {
  try {
    const photos = await getPhotos()
    photos.unshift(photo) // Add to beginning of array
    await savePhotos(photos)
  } catch (error) {
    console.error("Error adding photo:", error)
  }
}
