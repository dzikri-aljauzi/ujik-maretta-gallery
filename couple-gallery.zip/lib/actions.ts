"use server"

import { revalidatePath } from "next/cache"
import { put } from "@vercel/blob"
import { v4 as uuidv4 } from "uuid"
import { addPhoto } from "./photos"
import { updatePartnerProfile } from "./profiles"
import type { Photo, Profile } from "./types"

// Upload a photo
export async function uploadPhoto(file: File, data: { caption: string; description: string; partner: string }) {
  try {
    // Generate a safe filename
    const filename = file.name.replace(/[^a-zA-Z0-9.-]/g, "_")
    const uniqueFilename = `photos/${uuidv4()}-${filename}`

    // Upload to Vercel Blob
    const blob = await put(uniqueFilename, file, {
      access: "public",
      contentType: file.type,
      addRandomSuffix: true,
    })

    // Create photo object
    const photo: Photo = {
      id: uuidv4(),
      url: blob.url,
      caption: data.caption,
      description: data.description,
      date: new Date().toISOString(),
      partner: data.partner,
    }

    // Save to our data store
    await addPhoto(photo)

    // Revalidate paths
    revalidatePath("/")
    revalidatePath(`/profiles/${data.partner}`)

    return { success: true, photo }
  } catch (error) {
    console.error("Error uploading photo:", error)
    return { success: false, error: "Failed to upload photo. Please try again." }
  }
}

// Upload avatar
export async function uploadAvatar(file: File, partnerId: string) {
  try {
    // Generate a safe filename
    const filename = file.name.replace(/[^a-zA-Z0-9.-]/g, "_")
    const uniqueFilename = `avatars/${partnerId}-${uuidv4()}-${filename}`

    // Upload to Vercel Blob
    const blob = await put(uniqueFilename, file, {
      access: "public",
      contentType: file.type,
      addRandomSuffix: true,
    })

    // Update profile
    await updatePartnerProfile(partnerId, {
      avatar: blob.url,
    })

    // Revalidate path
    revalidatePath(`/profiles/${partnerId}`)

    return blob.url
  } catch (error) {
    console.error("Error uploading avatar:", error)
    throw new Error("Failed to upload avatar. Please try again.")
  }
}

// Update profile
export async function updateProfile(partnerId: string, data: Partial<Profile>) {
  try {
    await updatePartnerProfile(partnerId, data)

    // Revalidate path
    revalidatePath(`/profiles/${partnerId}`)

    return { success: true }
  } catch (error) {
    console.error("Error updating profile:", error)
    return { success: false, error: "Failed to update profile. Please try again." }
  }
}
